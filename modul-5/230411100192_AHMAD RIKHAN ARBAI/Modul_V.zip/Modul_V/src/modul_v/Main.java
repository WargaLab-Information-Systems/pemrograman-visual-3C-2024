/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package modul_v;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author HP
 */
public class Main extends javax.swing.JFrame {
DefaultTableModel model  = new DefaultTableModel();
DefaultTableModel model2  = new DefaultTableModel();
DefaultTableModel model3  = new DefaultTableModel();
Connection conn = koneksi.getConnection();
HashMap<String, Integer> karyawanMap = new HashMap<>(); 
HashMap<String, Integer> proyekMap = new HashMap<>();
    /**
     * Creates new form Soal_1
     */
    public Main() {
        initComponents();
        tbl_karyawan.setModel(model);
        model.addColumn("ID");
        model.addColumn("NAMA");
        model.addColumn("JABATAN");
        model.addColumn("DEPARTEMEN");
        loadData();
        btnsimpan.setVisible(false);
        btnupdate.setVisible(false);

        
        tbl_proyek.setModel(model2);
        model2.addColumn("ID");
        model2.addColumn("NAMA PROYEK");
        model2.addColumn("DURASI PROYEK/MINGGU"); 
        load();
        btnsimpan2.setVisible(false);
        btnupdate2.setVisible(false);
        
        
        tbl_transaksi.setModel(model3);
        model3.addColumn("ID");
        model3.addColumn("ID KARYAWAN"); 
        model3.addColumn("ID PROYEK"); 
        model3.addColumn("PERAN");
        loadtransaksi();
        data();
        btnsimpan3.setVisible(false);
        btnupdate3.setVisible(false);

    }
private void loadData() {
      model.setRowCount(0);
      try {
          String sql = "SELECT * FROM karyawan";
          PreparedStatement ps = conn.prepareStatement(sql);
          ResultSet rs = ps.executeQuery();         
          while (rs.next()) {
             // Menambahkan baris ke dalam model tabel
             model.addRow(new Object[]{
             rs.getInt("id"),
             rs.getString("Nama"),
             rs.getString("Jabatan"),
             rs.getString("Departemen")
           });
          }           
      } catch (SQLException e) {
         System.out.println("Error Save Data" + e.getMessage());
       }
       buttonGroup1.clearSelection();
       btnsimpan.setVisible(false);
       btnupdate.setVisible(false);
       txtnama.setText("");
       txtjabatan.setText("");
       txtdepartemen.setText("");
    }
private void load() {
      model2.setRowCount(0);
      try {
          String sql = "SELECT * FROM proyek";
          PreparedStatement ps = conn.prepareStatement(sql);
          ResultSet rs = ps.executeQuery();         
          while (rs.next()) {
             // Menambahkan baris ke dalam model tabel
             model2.addRow(new Object[]{
             rs.getInt("id"),
             rs.getString("Nama_Proyek"),
             rs.getString("Durasi_Pengerjaan")
           });
          }           
      } catch (SQLException e) {
         System.out.println("Error Save Data" + e.getMessage());
       }
       buttonGroup2.clearSelection();
       btnsimpan2.setVisible(false);
       btnupdate2.setVisible(false);
       txtproyek.setText("");
       txtdurasi.setText("");
    }
private void keluar(){
        ImageIcon icon = new ImageIcon(getClass().getResource("/modul_v/exit.png"));
        int response = JOptionPane.showConfirmDialog(null, "Apakah Anda Ingin Keluar", "Keluar", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, icon);
        if (response == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
}
private void loadtransaksi() {
    model3.setRowCount(0);
    try {
    String sql = "SELECT t.id_transaksi, t.id_proyek, t.id_karyawan, t.Peran, p.Nama_Proyek, k.Nama " +
                 "FROM transaksii t " +
                 "JOIN proyek p ON t.id_proyek = p.id " +
                 "JOIN karyawan k ON t.id_karyawan = k.id";
          PreparedStatement ps = conn.prepareStatement(sql);
          ResultSet rs = ps.executeQuery();         
          while (rs.next()) {
             // Menambahkan baris ke dalam model tabel
             model3.addRow(new Object[]{
             rs.getInt("id_transaksi"),
             rs.getString("id_karyawan"),
             rs.getString("id_proyek"),
             rs.getString("Peran")
           });
          }           
      } catch (SQLException e) {
         System.out.println("Error Save Data" + e.getMessage());
       }
}
private void data(){
    String proyek= "SELECT Nama_Proyek ,id FROM proyek"; 
    String karyawan = "SELECT Nama , id FROM karyawan"; 
    cbxproyek.removeAllItems();
    cbxkaryawan.removeAllItems();
    proyekMap.clear();
    karyawanMap.clear();
    
    try (PreparedStatement psKaryawan = conn.prepareStatement(karyawan);
         ResultSet rsKaryawan = psKaryawan.executeQuery()) {

        while (rsKaryawan.next()) {
            String namaKaryawan = rsKaryawan.getString("Nama");
            cbxkaryawan.addItem(namaKaryawan);
            int idKaryawan = rsKaryawan.getInt("id");
            karyawanMap.put(namaKaryawan, idKaryawan);
        }
    } catch (SQLException e) {
        System.out.println("Error Save Data" + e.getMessage());
    }
    
    try (PreparedStatement psProyek = conn.prepareStatement(proyek);
         ResultSet rsProyek = psProyek.executeQuery()) {

        while (rsProyek.next()) {
            String namaProyek = rsProyek.getString("Nama_Proyek"); 
            cbxproyek.addItem(namaProyek);
            int idProyek = rsProyek.getInt("id");
            proyekMap.put(namaProyek, idProyek);
        }
    } catch (SQLException e) {
        System.out.println("Error Save Data" + e.getMessage());
    }

}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        txtnama = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtjabatan = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtdepartemen = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        rdbtambah = new javax.swing.JRadioButton();
        rdbupdate = new javax.swing.JRadioButton();
        btnsimpan = new javax.swing.JButton();
        btnreset = new javax.swing.JButton();
        btnkeluar = new javax.swing.JButton();
        btndelete = new javax.swing.JButton();
        btnupdate = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_karyawan = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        txtproyek = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtdurasi = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        rdbtambah2 = new javax.swing.JRadioButton();
        rdbupdate2 = new javax.swing.JRadioButton();
        btnsimpan2 = new javax.swing.JButton();
        btnreset2 = new javax.swing.JButton();
        btnkeluar2 = new javax.swing.JButton();
        btndelete2 = new javax.swing.JButton();
        btnupdate2 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_proyek = new javax.swing.JTable();
        jPanel9 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        rdbtambah3 = new javax.swing.JRadioButton();
        rdbupdate3 = new javax.swing.JRadioButton();
        btnsimpan3 = new javax.swing.JButton();
        btnreset3 = new javax.swing.JButton();
        btnkeluar3 = new javax.swing.JButton();
        btndelete3 = new javax.swing.JButton();
        btnupdate3 = new javax.swing.JButton();
        cbxkaryawan = new javax.swing.JComboBox<>();
        cbxproyek = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        txtperan = new javax.swing.JTextField();
        jPanel11 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_transaksi = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(102, 255, 255));
        jPanel4.setLayout(null);
        jPanel4.add(txtnama);
        txtnama.setBounds(180, 10, 350, 35);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("JABATAN");
        jPanel4.add(jLabel2);
        jLabel2.setBounds(30, 60, 90, 20);
        jPanel4.add(txtjabatan);
        txtjabatan.setBounds(180, 50, 350, 35);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("DEPARTEMEN");
        jPanel4.add(jLabel3);
        jLabel3.setBounds(30, 100, 130, 20);
        jPanel4.add(txtdepartemen);
        txtdepartemen.setBounds(180, 90, 350, 35);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("NAMA");
        jPanel4.add(jLabel4);
        jLabel4.setBounds(30, 20, 90, 20);

        buttonGroup1.add(rdbtambah);
        rdbtambah.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        rdbtambah.setText("Tambah Data");
        rdbtambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbtambahActionPerformed(evt);
            }
        });
        jPanel4.add(rdbtambah);
        rdbtambah.setBounds(180, 130, 160, 31);

        buttonGroup1.add(rdbupdate);
        rdbupdate.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        rdbupdate.setText("Update Data");
        rdbupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbupdateActionPerformed(evt);
            }
        });
        jPanel4.add(rdbupdate);
        rdbupdate.setBounds(390, 130, 142, 31);

        btnsimpan.setBackground(new java.awt.Color(51, 102, 255));
        btnsimpan.setText("Simpan");
        btnsimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsimpanActionPerformed(evt);
            }
        });
        jPanel4.add(btnsimpan);
        btnsimpan.setBounds(220, 170, 108, 35);

        btnreset.setBackground(new java.awt.Color(255, 255, 102));
        btnreset.setText("Reset");
        btnreset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnresetActionPerformed(evt);
            }
        });
        jPanel4.add(btnreset);
        btnreset.setBounds(340, 170, 120, 35);

        btnkeluar.setBackground(new java.awt.Color(51, 51, 51));
        btnkeluar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/modul_v/exit.png"))); // NOI18N
        btnkeluar.setText("Keluar");
        btnkeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnkeluarActionPerformed(evt);
            }
        });
        jPanel4.add(btnkeluar);
        btnkeluar.setBounds(30, 130, 140, 42);

        btndelete.setBackground(new java.awt.Color(255, 0, 0));
        btndelete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/modul_v/delete.png"))); // NOI18N
        btndelete.setText("Delete");
        btndelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeleteActionPerformed(evt);
            }
        });
        jPanel4.add(btndelete);
        btndelete.setBounds(30, 180, 140, 42);

        btnupdate.setBackground(new java.awt.Color(51, 51, 255));
        btnupdate.setText("Update");
        btnupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdateActionPerformed(evt);
            }
        });
        jPanel4.add(btnupdate);
        btnupdate.setBounds(220, 170, 108, 35);

        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 230));

        jPanel5.setLayout(new java.awt.GridLayout(1, 0));

        tbl_karyawan.setBackground(new java.awt.Color(242, 242, 242));
        tbl_karyawan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tbl_karyawan);

        jPanel5.add(jScrollPane1);

        jPanel3.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 230, 570, 370));

        jTabbedPane1.addTab("Form Karyawan", jPanel3);

        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel7.setBackground(new java.awt.Color(102, 255, 255));
        jPanel7.setLayout(null);
        jPanel7.add(txtproyek);
        txtproyek.setBounds(180, 10, 350, 35);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("DURASI/MINGGU");
        jPanel7.add(jLabel6);
        jLabel6.setBounds(20, 60, 151, 20);
        jPanel7.add(txtdurasi);
        txtdurasi.setBounds(180, 50, 350, 35);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("NAMA PROYEK");
        jPanel7.add(jLabel8);
        jLabel8.setBounds(30, 20, 140, 20);

        buttonGroup2.add(rdbtambah2);
        rdbtambah2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        rdbtambah2.setText("Tambah Data");
        rdbtambah2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbtambah2ActionPerformed(evt);
            }
        });
        jPanel7.add(rdbtambah2);
        rdbtambah2.setBounds(180, 90, 160, 31);

        buttonGroup2.add(rdbupdate2);
        rdbupdate2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        rdbupdate2.setText("Update Data");
        rdbupdate2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbupdate2ActionPerformed(evt);
            }
        });
        jPanel7.add(rdbupdate2);
        rdbupdate2.setBounds(390, 90, 142, 31);

        btnsimpan2.setBackground(new java.awt.Color(51, 102, 255));
        btnsimpan2.setText("Simpan");
        btnsimpan2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsimpan2ActionPerformed(evt);
            }
        });
        jPanel7.add(btnsimpan2);
        btnsimpan2.setBounds(10, 130, 108, 35);

        btnreset2.setBackground(new java.awt.Color(255, 255, 102));
        btnreset2.setText("Reset");
        btnreset2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnreset2ActionPerformed(evt);
            }
        });
        jPanel7.add(btnreset2);
        btnreset2.setBounds(280, 130, 120, 35);

        btnkeluar2.setBackground(new java.awt.Color(51, 51, 51));
        btnkeluar2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/modul_v/exit.png"))); // NOI18N
        btnkeluar2.setText("Keluar");
        btnkeluar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnkeluar2ActionPerformed(evt);
            }
        });
        jPanel7.add(btnkeluar2);
        btnkeluar2.setBounds(410, 160, 140, 42);

        btndelete2.setBackground(new java.awt.Color(255, 0, 0));
        btndelete2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/modul_v/delete.png"))); // NOI18N
        btndelete2.setText("Delete");
        btndelete2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndelete2ActionPerformed(evt);
            }
        });
        jPanel7.add(btndelete2);
        btndelete2.setBounds(130, 160, 140, 42);

        btnupdate2.setBackground(new java.awt.Color(51, 51, 255));
        btnupdate2.setText("Update");
        btnupdate2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdate2ActionPerformed(evt);
            }
        });
        jPanel7.add(btnupdate2);
        btnupdate2.setBounds(10, 130, 108, 35);

        jPanel6.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 230));

        jPanel8.setLayout(new java.awt.GridLayout(1, 0));

        tbl_proyek.setBackground(new java.awt.Color(242, 242, 242));
        tbl_proyek.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tbl_proyek);

        jPanel8.add(jScrollPane2);

        jPanel6.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 230, 570, 370));

        jTabbedPane1.addTab("Form Proyek", jPanel6);

        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel10.setBackground(new java.awt.Color(102, 255, 255));
        jPanel10.setLayout(null);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setText("PERAN");
        jPanel10.add(jLabel7);
        jLabel7.setBounds(20, 100, 60, 20);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setText("NAMA KARYAWAN");
        jPanel10.add(jLabel9);
        jLabel9.setBounds(20, 20, 170, 20);

        buttonGroup3.add(rdbtambah3);
        rdbtambah3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        rdbtambah3.setText("Tambah Data");
        rdbtambah3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbtambah3ActionPerformed(evt);
            }
        });
        jPanel10.add(rdbtambah3);
        rdbtambah3.setBounds(180, 130, 160, 31);

        buttonGroup3.add(rdbupdate3);
        rdbupdate3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        rdbupdate3.setText("Update Data");
        rdbupdate3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbupdate3ActionPerformed(evt);
            }
        });
        jPanel10.add(rdbupdate3);
        rdbupdate3.setBounds(390, 130, 142, 31);

        btnsimpan3.setBackground(new java.awt.Color(51, 102, 255));
        btnsimpan3.setText("Simpan");
        btnsimpan3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsimpan3ActionPerformed(evt);
            }
        });
        jPanel10.add(btnsimpan3);
        btnsimpan3.setBounds(220, 170, 108, 35);

        btnreset3.setBackground(new java.awt.Color(255, 255, 102));
        btnreset3.setText("Reset");
        btnreset3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnreset3ActionPerformed(evt);
            }
        });
        jPanel10.add(btnreset3);
        btnreset3.setBounds(340, 170, 120, 35);

        btnkeluar3.setBackground(new java.awt.Color(51, 51, 51));
        btnkeluar3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/modul_v/exit.png"))); // NOI18N
        btnkeluar3.setText("Keluar");
        btnkeluar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnkeluar3ActionPerformed(evt);
            }
        });
        jPanel10.add(btnkeluar3);
        btnkeluar3.setBounds(30, 130, 140, 42);

        btndelete3.setBackground(new java.awt.Color(255, 0, 0));
        btndelete3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/modul_v/delete.png"))); // NOI18N
        btndelete3.setText("Delete");
        btndelete3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndelete3ActionPerformed(evt);
            }
        });
        jPanel10.add(btndelete3);
        btndelete3.setBounds(30, 180, 140, 42);

        btnupdate3.setBackground(new java.awt.Color(51, 51, 255));
        btnupdate3.setText("Update");
        btnupdate3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdate3ActionPerformed(evt);
            }
        });
        jPanel10.add(btnupdate3);
        btnupdate3.setBounds(220, 170, 108, 35);

        jPanel10.add(cbxkaryawan);
        cbxkaryawan.setBounds(210, 10, 330, 35);

        jPanel10.add(cbxproyek);
        cbxproyek.setBounds(210, 50, 330, 35);

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setText("NAMA PROYEK");
        jPanel10.add(jLabel10);
        jLabel10.setBounds(20, 60, 132, 20);
        jPanel10.add(txtperan);
        txtperan.setBounds(210, 90, 330, 35);

        jPanel9.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 230));

        jPanel11.setLayout(new java.awt.GridLayout());

        tbl_transaksi.setBackground(new java.awt.Color(242, 242, 242));
        tbl_transaksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(tbl_transaksi);

        jPanel11.add(jScrollPane3);

        jPanel9.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 230, 570, 370));

        jTabbedPane1.addTab("Form Transaksi", jPanel9);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 569, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 646, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnkeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnkeluarActionPerformed
        // TODO add your handling code here:
        keluar();
    }//GEN-LAST:event_btnkeluarActionPerformed

    private void btnresetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnresetActionPerformed
        // TODO add your handling code here:
        txtnama.setText("");
        txtjabatan.setText("");
        txtdepartemen.setText("");
        buttonGroup1.clearSelection();
        btnsimpan.setVisible(false);
        btnupdate.setVisible(false);
    }//GEN-LAST:event_btnresetActionPerformed

    private void btndeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeleteActionPerformed
        // TODO add your handling code here:
        try {
            // Memuat ikon
            ImageIcon icon = new ImageIcon(getClass().getResource("/modul_v/delete.png"));
            ImageIcon icon2 = new ImageIcon(getClass().getResource("/modul_v/info.png"));
            // Meminta input ID dari pengguna
            String input = (String) JOptionPane.showInputDialog(null, 
                "Silakan Masukkan ID", 
                "HAPUS DATA", 
                JOptionPane.PLAIN_MESSAGE, 
                icon, 
                null, 
                null);

            if (input != null && !input.trim().isEmpty()) {
                int id = Integer.parseInt(input);

                // Periksa apakah data dengan ID yang dimasukkan ada di dalam tabel
                String checkSql = "SELECT COUNT(*) FROM karyawan WHERE id = ?";
                PreparedStatement checkStmt = conn.prepareStatement(checkSql);
                checkStmt.setInt(1, id);

                ResultSet rs = checkStmt.executeQuery();
                rs.next();
                int count = rs.getInt(1);

                if (count > 0) {
                    // Jika data ditemukan, minta konfirmasi untuk menghapus
                    int confirm = JOptionPane.showConfirmDialog(null, 
                        "Apakah Anda yakin ingin menghapus data ini?", 
                        "Konfirmasi Hapus", 
                        JOptionPane.YES_NO_OPTION, 
                        JOptionPane.WARNING_MESSAGE);

                    if (confirm == JOptionPane.YES_OPTION) {
                        // Eksekusi query DELETE
                        String deleteSql = "DELETE FROM karyawan WHERE id = ?";
                        PreparedStatement deleteStmt = conn.prepareStatement(deleteSql);
                        deleteStmt.setInt(1, id);
                        deleteStmt.executeUpdate();
                        
                        
                      
                        conn.prepareStatement("SET @count = 0;").execute();
                        conn.prepareStatement("UPDATE karyawan SET id = @count := @count + 1;").executeUpdate();
                        conn.prepareStatement("ALTER TABLE karyawan AUTO_INCREMENT = 1;").execute();

                    
                        JOptionPane.showMessageDialog(null, "Data berhasil dihapus!", "KONFIRMASI", JOptionPane.INFORMATION_MESSAGE, icon2);
                    } else {
                        JOptionPane.showMessageDialog(null, "Penghapusan dibatalkan.");
                    }
                } else {
                    // Jika data tidak ditemukan, beri tahu pengguna
                    JOptionPane.showMessageDialog(null, "Data dengan ID tersebut tidak ditemukan.", "INFORMASI", JOptionPane.INFORMATION_MESSAGE, icon2);
                }
            } else {
                JOptionPane.showMessageDialog(null, "ID tidak valid atau tidak diisi.", "INFORMASI", JOptionPane.INFORMATION_MESSAGE, icon2);
            }
            loadData();
            data();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
        }
    }//GEN-LAST:event_btndeleteActionPerformed

    private void btnsimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsimpanActionPerformed
        // TODO add your handling code here:
               try {
            ImageIcon icon = new ImageIcon(getClass().getResource("/modul_v/save.png"));
            // Validasi apakah semua field telah diisi
            if (txtnama.getText().trim().isEmpty() || txtjabatan.getText().trim().isEmpty()|| txtdepartemen.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Semua kolom harus diisi!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return; // Menghentikan proses jika ada field yang kosong
            }

            // Menyiapkan query SQL untuk insert
            String sql = "INSERT INTO karyawan (nama, Jabatan, Departemen) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);

            // Mengisi parameter dengan nilai dari JTextField
            ps.setString(1, txtnama.getText());
            ps.setString(2, txtjabatan.getText());
            ps.setString(3, txtdepartemen.getText());

            // Eksekusi query insert
            ps.executeUpdate();

            // Menampilkan pesan sukses
            JOptionPane.showMessageDialog(null, "Data berhasil disimpan!", "INFORMASI",  JOptionPane.INFORMATION_MESSAGE, icon);

            // Memuat ulang data setelah penyimpanan
            loadData();
            data();

        } catch (SQLException e) {
            System.out.println("Error Save Data: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat menyimpan data: " + e.getMessage(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnsimpanActionPerformed

    private void rdbtambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbtambahActionPerformed
        // TODO add your handling code here:
        if(rdbtambah.isSelected()){
        btnsimpan.setVisible(true);
        btnupdate.setVisible(false);
    }
        
    }//GEN-LAST:event_rdbtambahActionPerformed

    private void rdbupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbupdateActionPerformed
        // TODO add your handling code here:
    if(rdbupdate.isSelected()){
        btnsimpan.setVisible(false);
        btnupdate.setVisible(true);
    }
    }//GEN-LAST:event_rdbupdateActionPerformed

    private void btnupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdateActionPerformed
        // TODO add your handling code here:
    try {
                ImageIcon save = new ImageIcon(getClass().getResource("/modul_v/save.png"));
                ImageIcon icon = new ImageIcon(getClass().getResource("/modul_v/thinking.png"));
                // Cek apakah semua field telah diisi
                if (txtnama.getText().trim().isEmpty() || txtjabatan.getText().trim().isEmpty() || txtdepartemen.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Semua kolom harus diisi!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                    return; // Jika ada field yang kosong, hentikan proses
                }

                // Menyiapkan query SQL untuk update
                String sql = "UPDATE karyawan SET nama = ?, Jabatan = ?, Departemen = ? WHERE id = ?";
                PreparedStatement ps = conn.prepareStatement(sql);

                // Mengisi parameter dengan nilai dari JTextField
                ps.setString(1, txtnama.getText());
                ps.setString(2, txtjabatan.getText());
                ps.setString(3, txtdepartemen.getText());

                // Meminta pengguna memasukkan ID untuk data yang akan diupdate
                int id = Integer.parseInt((String)JOptionPane.showInputDialog(null, 
                    "Silakan Masukkan ID", 
                    "UPDATE DATA", 
                    JOptionPane.PLAIN_MESSAGE, 
                    icon, 
                    null, 
                    null));
                ps.setInt(4, id);
                // Eksekusi query update
                int rowsAffected = ps.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "Data berhasil diperbarui!","MESSAGE",JOptionPane.INFORMATION_MESSAGE,save);
                    loadData(); // Memuat ulang data setelah pembaruan
                    data();
                } else {
                    JOptionPane.showMessageDialog(null, "ID tidak ditemukan atau data tidak diperbarui.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
                }

            } catch (SQLException e) {
                System.out.println("Error Update Data: " + e.getMessage());
                JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "ID tidak valid. Harap masukkan ID yang benar.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
    }//GEN-LAST:event_btnupdateActionPerformed
   
    
    
   
    
    
    private void rdbtambah2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbtambah2ActionPerformed
        // TODO add your handling code here:
        if(rdbtambah2.isSelected()){
        btnsimpan2.setVisible(true);
        btnupdate2.setVisible(false);
    }
    }//GEN-LAST:event_rdbtambah2ActionPerformed

    private void rdbupdate2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbupdate2ActionPerformed
    if(rdbupdate2.isSelected()){
        btnsimpan2.setVisible(false);
        btnupdate2.setVisible(true);
    }
    }//GEN-LAST:event_rdbupdate2ActionPerformed

    private void btnsimpan2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsimpan2ActionPerformed
    try {
            ImageIcon icon = new ImageIcon(getClass().getResource("/modul_v/save.png"));
            // Validasi apakah semua field telah diisi
            if (txtproyek.getText().trim().isEmpty() || txtdurasi.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Semua kolom harus diisi!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return; // Menghentikan proses jika ada field yang kosong
            }

            // Menyiapkan query SQL untuk insert
            String sql = "INSERT INTO proyek (Nama_Proyek, Durasi_Pengerjaan) VALUES (?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);

            // Mengisi parameter dengan nilai dari JTextField
            ps.setString(1, txtproyek.getText());
            ps.setString(2, txtdurasi.getText());

            // Eksekusi query insert
            ps.executeUpdate();

            // Menampilkan pesan sukses
            JOptionPane.showMessageDialog(null, "Data berhasil disimpan!", "INFORMASI",  JOptionPane.INFORMATION_MESSAGE, icon);

            // Memuat ulang data setelah penyimpanan
            load();
            data();

        } catch (SQLException e) {
            System.out.println("Error Save Data: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat menyimpan data: " + e.getMessage(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnsimpan2ActionPerformed

    private void btnreset2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnreset2ActionPerformed
        // TODO add your handling code here:
        txtproyek.setText("");
        txtdurasi.setText("");
        buttonGroup2.clearSelection();
        btnsimpan2.setVisible(false);
        btnupdate2.setVisible(false);
    }//GEN-LAST:event_btnreset2ActionPerformed

    private void btnkeluar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnkeluar2ActionPerformed
        // TODO add your handling code here:
        keluar();
    }//GEN-LAST:event_btnkeluar2ActionPerformed

    private void btndelete2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndelete2ActionPerformed
        try {
            // Memuat ikon
            ImageIcon icon = new ImageIcon(getClass().getResource("/modul_v/delete.png"));
            ImageIcon icon2 = new ImageIcon(getClass().getResource("/modul_v/info.png"));
            // Meminta input ID dari pengguna
            String input = (String) JOptionPane.showInputDialog(null, 
                "Silakan Masukkan ID", 
                "HAPUS DATA", 
                JOptionPane.PLAIN_MESSAGE, 
                icon, 
                null, 
                null);

            if (input != null && !input.trim().isEmpty()) {
                int id = Integer.parseInt(input);

                // Periksa apakah data dengan ID yang dimasukkan ada di dalam tabel
                String checkSql = "SELECT COUNT(*) FROM proyek WHERE id = ?";
                PreparedStatement checkStmt = conn.prepareStatement(checkSql);
                checkStmt.setInt(1, id);

                ResultSet rs = checkStmt.executeQuery();
                rs.next();
                int count = rs.getInt(1);

                if (count > 0) {
                    // Jika data ditemukan, minta konfirmasi untuk menghapus
                    int confirm = JOptionPane.showConfirmDialog(null, 
                        "Apakah Anda yakin ingin menghapus data ini?", 
                        "Konfirmasi Hapus", 
                        JOptionPane.YES_NO_OPTION, 
                        JOptionPane.WARNING_MESSAGE);

                    if (confirm == JOptionPane.YES_OPTION) {
                        // Eksekusi query DELETE
                        String deleteSql = "DELETE FROM proyek WHERE id = ?";
                        PreparedStatement deleteStmt = conn.prepareStatement(deleteSql);
                        deleteStmt.setInt(1, id);
                        deleteStmt.executeUpdate();
                        
                        
                      
                        conn.prepareStatement("SET @count = 0;").execute();
                        conn.prepareStatement("UPDATE proyek SET id = @count := @count + 1;").executeUpdate();
                        conn.prepareStatement("ALTER TABLE karyawan AUTO_INCREMENT = 1;").execute();

                    
                        JOptionPane.showMessageDialog(null, "Data berhasil dihapus!", "KONFIRMASI", JOptionPane.INFORMATION_MESSAGE, icon2);
                    } else {
                        JOptionPane.showMessageDialog(null, "Penghapusan dibatalkan.");
                    }
                } else {
                    // Jika data tidak ditemukan, beri tahu pengguna
                    JOptionPane.showMessageDialog(null, "Data dengan ID tersebut tidak ditemukan.", "INFORMASI", JOptionPane.INFORMATION_MESSAGE, icon2);
                }
            } else {
                JOptionPane.showMessageDialog(null, "ID tidak valid atau tidak diisi.", "INFORMASI", JOptionPane.INFORMATION_MESSAGE, icon2);
            }
            load();
            data();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
        }
    }//GEN-LAST:event_btndelete2ActionPerformed

    private void btnupdate2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdate2ActionPerformed
        try {
                ImageIcon save = new ImageIcon(getClass().getResource("/modul_v/save.png"));
                ImageIcon icon = new ImageIcon(getClass().getResource("/modul_v/thinking.png"));
                // Cek apakah semua field telah diisi
                if (txtproyek.getText().trim().isEmpty() || txtdurasi.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Semua kolom harus diisi!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                    return; // Jika ada field yang kosong, hentikan proses
                }

                // Menyiapkan query SQL untuk update
                String sql = "UPDATE proyek SET Nama_Proyek = ?, Durasi_Pengerjaan = ? WHERE id = ?";
                PreparedStatement ps = conn.prepareStatement(sql);

                // Mengisi parameter dengan nilai dari JTextField
                ps.setString(1, txtproyek.getText());
                ps.setString(2, txtdurasi.getText());

                // Meminta pengguna memasukkan ID untuk data yang akan diupdate
                int id = Integer.parseInt((String)JOptionPane.showInputDialog(null, 
                    "Silakan Masukkan ID", 
                    "UPDATE DATA", 
                    JOptionPane.PLAIN_MESSAGE, 
                    icon, 
                    null, 
                    null));
                ps.setInt(3, id);
                // Eksekusi query update
                int rowsAffected = ps.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "Data berhasil diperbarui!","MESSAGE",JOptionPane.INFORMATION_MESSAGE,save);
                    load(); // Memuat ulang data setelah pembaruan
                    data();
                } else {
                    JOptionPane.showMessageDialog(null, "ID tidak ditemukan atau data tidak diperbarui.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
                }

            } catch (SQLException e) {
                System.out.println("Error Update Data: " + e.getMessage());
                JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "ID tidak valid. Harap masukkan ID yang benar.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
    }//GEN-LAST:event_btnupdate2ActionPerformed

    
    
    
    
    private void rdbtambah3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbtambah3ActionPerformed
        if(rdbtambah3.isSelected()){
        btnsimpan3.setVisible(true);
        btnupdate3.setVisible(false);
    }
    }//GEN-LAST:event_rdbtambah3ActionPerformed

    private void rdbupdate3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbupdate3ActionPerformed
    if(rdbupdate3.isSelected()){
        btnsimpan3.setVisible(false);
        btnupdate3.setVisible(true);
    }
    }//GEN-LAST:event_rdbupdate3ActionPerformed

    private void btnsimpan3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsimpan3ActionPerformed
        try {
            ImageIcon icon = new ImageIcon(getClass().getResource("/modul_v/save.png"));
            // Validasi apakah semua field telah diisi
            if (txtperan.getText().trim().isEmpty() ) {
                JOptionPane.showMessageDialog(null, "Semua kolom harus diisi!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return; // Menghentikan proses jika ada field yang kosong
            }
            
            
            
            String selectedKaryawan = (String) cbxkaryawan.getSelectedItem();
            String selectedProyek = (String) cbxproyek.getSelectedItem();
            String peran = txtperan.getText();  // Mendapatkan nilai peran dari TextField
            int idKaryawan = karyawanMap.get(selectedKaryawan);
            int idProyek = proyekMap.get(selectedProyek);

            String sqlInsert = "INSERT INTO transaksii (id_karyawan, id_proyek, Peran) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sqlInsert);
            ps.setInt(1, idKaryawan);
            ps.setInt(2, idProyek);
            ps.setString(3, peran);  // Menyimpan nilai peran ke database
            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Data berhasil disimpan!", "INFORMASI",  JOptionPane.INFORMATION_MESSAGE, icon);

            loadtransaksi();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
        cbxkaryawan.setSelectedIndex(0);
        cbxproyek.setSelectedIndex(0);
        txtperan.setText("");
        buttonGroup3.clearSelection();
        btnsimpan3.setVisible(false);
        btnupdate3.setVisible(false);
    
    }//GEN-LAST:event_btnsimpan3ActionPerformed

    private void btnreset3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnreset3ActionPerformed
        cbxkaryawan.setSelectedIndex(0);
        cbxproyek.setSelectedIndex(0);
        txtperan.setText("");
        buttonGroup3.clearSelection();
        btnsimpan3.setVisible(false);
        btnupdate3.setVisible(false);
    }//GEN-LAST:event_btnreset3ActionPerformed

    private void btnkeluar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnkeluar3ActionPerformed
        keluar();
    }//GEN-LAST:event_btnkeluar3ActionPerformed

    private void btndelete3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndelete3ActionPerformed
        try {
            // Memuat ikon
            ImageIcon iconDelete = new ImageIcon(getClass().getResource("/modul_v/delete.png"));
            ImageIcon iconInfo = new ImageIcon(getClass().getResource("/modul_v/info.png"));

            // Meminta input nama karyawan dan nama proyek dari pengguna
            String selectedKaryawan = String.valueOf(JOptionPane.showInputDialog(null, "Masukkan nama karyawan:", "Input Nama Karyawan", JOptionPane.INFORMATION_MESSAGE, iconDelete, null, null));
            String selectedProyek = String.valueOf(JOptionPane.showInputDialog(null, "Masukkan nama proyek:", "Input Nama Proyek", JOptionPane.QUESTION_MESSAGE));

            if (selectedKaryawan == null || selectedProyek == null || selectedKaryawan.trim().isEmpty() || selectedProyek.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Nama karyawan dan nama proyek harus diisi!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Mendapatkan id_karyawan berdasarkan nama karyawan
            String sqlKaryawan = "SELECT id FROM karyawan WHERE Nama = ?";
            PreparedStatement psKaryawan = conn.prepareStatement(sqlKaryawan);
            psKaryawan.setString(1, selectedKaryawan);
            ResultSet rsKaryawan = psKaryawan.executeQuery();
            int idKaryawan = -1;
            if (rsKaryawan.next()) {
                idKaryawan = rsKaryawan.getInt("id");
            }

            // Mendapatkan id_proyek berdasarkan nama proyek
            String sqlProyek = "SELECT id FROM proyek WHERE Nama_Proyek = ?";
            PreparedStatement psProyek = conn.prepareStatement(sqlProyek);
            psProyek.setString(1, selectedProyek);
            ResultSet rsProyek = psProyek.executeQuery();
            int idProyek = -1;
            if (rsProyek.next()) {
                idProyek = rsProyek.getInt("id");
            }

            // Pastikan id_karyawan dan id_proyek ditemukan
            if (idKaryawan != -1 && idProyek != -1) {
                // Konfirmasi penghapusan
                int confirm = JOptionPane.showConfirmDialog(null,
                        "Apakah Anda yakin ingin menghapus data untuk karyawan " + selectedKaryawan +
                        " pada proyek " + selectedProyek + "?",
                        "Konfirmasi Hapus",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE);

                if (confirm == JOptionPane.YES_OPTION) {
                    // Eksekusi query DELETE berdasarkan id_karyawan dan id_proyek
                    String deleteSql = "DELETE FROM transaksii WHERE id_karyawan = ? AND id_proyek = ?";
                    PreparedStatement deleteStmt = conn.prepareStatement(deleteSql);
                    deleteStmt.setInt(1, idKaryawan);
                    deleteStmt.setInt(2, idProyek);
                    int rowsDeleted = deleteStmt.executeUpdate();

                    if (rowsDeleted > 0) {
                        JOptionPane.showMessageDialog(null, "Data berhasil dihapus!", "KONFIRMASI", JOptionPane.INFORMATION_MESSAGE, iconInfo);
                    } else {
                        JOptionPane.showMessageDialog(null, "Data tidak ditemukan.", "INFORMASI", JOptionPane.INFORMATION_MESSAGE, iconInfo);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Penghapusan dibatalkan.");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Data karyawan atau proyek tidak ditemukan.", "INFORMASI", JOptionPane.INFORMATION_MESSAGE, iconInfo);
            }

            // Refresh data setelah penghapusan
            loadtransaksi();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
        }

    }//GEN-LAST:event_btndelete3ActionPerformed

    private void btnupdate3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdate3ActionPerformed
        try {
            ImageIcon icon = new ImageIcon(getClass().getResource("/modul_v/save.png"));

            // Validasi apakah semua field telah diisi
            if (txtperan.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Semua kolom harus diisi!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return; // Menghentikan proses jika ada field yang kosong
            }

            String selectedKaryawan = (String) cbxkaryawan.getSelectedItem();
            String selectedProyek = (String) cbxproyek.getSelectedItem();
            String peran = txtperan.getText(); // Mendapatkan nilai peran dari TextField
            int idKaryawan = karyawanMap.get(selectedKaryawan);
            int idProyek = proyekMap.get(selectedProyek);

            // Perbarui data transaksi di database
            String sqlUpdate = "UPDATE transaksii SET Peran = ? WHERE id_karyawan = ? AND id_proyek = ?";
            PreparedStatement ps = conn.prepareStatement(sqlUpdate);
            ps.setString(1, peran);    // Menyimpan nilai peran yang baru
            ps.setInt(2, idKaryawan);  // Berdasarkan id_karyawan
            ps.setInt(3, idProyek);    // Berdasarkan id_proyek
            int rowsUpdated = ps.executeUpdate();

            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Data berhasil diperbarui!", "INFORMASI", JOptionPane.INFORMATION_MESSAGE, icon);
            } else {
                JOptionPane.showMessageDialog(null, "Data tidak ditemukan atau tidak ada perubahan.", "INFORMASI", JOptionPane.INFORMATION_MESSAGE);
            }

            // Refresh data setelah update
            loadtransaksi();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }

        // Mengembalikan komponen ke keadaan semula setelah update
        cbxkaryawan.setSelectedIndex(0);
        cbxproyek.setSelectedIndex(0);
        txtperan.setText("");
        buttonGroup3.clearSelection();
        btnsimpan3.setVisible(false);
        btnupdate3.setVisible(false);

    }//GEN-LAST:event_btnupdate3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Main().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btndelete;
    private javax.swing.JButton btndelete2;
    private javax.swing.JButton btndelete3;
    private javax.swing.JButton btnkeluar;
    private javax.swing.JButton btnkeluar2;
    private javax.swing.JButton btnkeluar3;
    private javax.swing.JButton btnreset;
    private javax.swing.JButton btnreset2;
    private javax.swing.JButton btnreset3;
    private javax.swing.JButton btnsimpan;
    private javax.swing.JButton btnsimpan2;
    private javax.swing.JButton btnsimpan3;
    private javax.swing.JButton btnupdate;
    private javax.swing.JButton btnupdate2;
    private javax.swing.JButton btnupdate3;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JComboBox<String> cbxkaryawan;
    private javax.swing.JComboBox<String> cbxproyek;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JRadioButton rdbtambah;
    private javax.swing.JRadioButton rdbtambah2;
    private javax.swing.JRadioButton rdbtambah3;
    private javax.swing.JRadioButton rdbupdate;
    private javax.swing.JRadioButton rdbupdate2;
    private javax.swing.JRadioButton rdbupdate3;
    private javax.swing.JTable tbl_karyawan;
    private javax.swing.JTable tbl_proyek;
    private javax.swing.JTable tbl_transaksi;
    private javax.swing.JTextField txtdepartemen;
    private javax.swing.JTextField txtdurasi;
    private javax.swing.JTextField txtjabatan;
    private javax.swing.JTextField txtnama;
    private javax.swing.JTextField txtperan;
    private javax.swing.JTextField txtproyek;
    // End of variables declaration//GEN-END:variables
}
