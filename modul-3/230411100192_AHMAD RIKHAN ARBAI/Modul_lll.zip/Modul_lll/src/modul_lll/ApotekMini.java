/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package modul_lll;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ApotekMini {

    // Array nama-nama obat
    String[] namaObat = {
        "Paracetamol", "Amoxicillin", "Ibuprofen", "Antasida", "Ciprofloxacin",
        "Cetirizine", "Loratadine", "Omeprazole", "Metformin", "Simvastatin"
    };

    // Array deskripsi obat-obatan
    String[] deskripsiObat = {
        "Paracetamol: Digunakan untuk meredakan demam dan nyeri ringan hingga sedang.",
        "Amoxicillin: Antibiotik yang digunakan untuk infeksi bakteri.",
        "Ibuprofen: Pereda nyeri untuk kondisi seperti sakit gigi, sakit kepala, dan nyeri otot.",
        "Antasida: Digunakan untuk mengurangi asam lambung, meringankan gejala maag.",
        "Ciprofloxacin: Antibiotik untuk mengobati infeksi bakteri tertentu.",
        "Cetirizine: Obat untuk meredakan gejala alergi seperti gatal, bersin, dan pilek.",
        "Loratadine: Obat antihistamin yang digunakan untuk mengobati gejala alergi.",
        "Omeprazole: Obat untuk mengobati masalah perut seperti refluks asam lambung.",
        "Metformin: Digunakan untuk mengontrol gula darah pada pasien diabetes tipe 2.",
        "Simvastatin: Obat yang membantu menurunkan kolesterol dalam darah."
    };

    public static void main(String[] args) {
        // Membuat frame utama
        new ApotekMini().createAndShowGUI();
    }

    private void createAndShowGUI() {
        // Frame utama
        JFrame frame = new JFrame("Apotek Mini");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Panel input (FlowLayout)
        JPanel panelInput = new JPanel(new FlowLayout());
        panelInput.add(new JLabel("Pilih gejala atau keluhan:"));
        
        String[] gejala = {"Demam", "Infeksi Bakteri", "Nyeri", "Maag", "Alergi", "Asam Lambung", "Kolesterol", "Diabetes"};
        JComboBox<String> comboGejala = new JComboBox<>(gejala);
        panelInput.add(comboGejala);

        JButton btnCariObat = new JButton("Cari Obat");
        panelInput.add(btnCariObat);
        frame.add(panelInput, BorderLayout.NORTH);

        // Panel untuk daftar obat (GridLayout)
        JPanel panelObat = new JPanel(new GridLayout(5, 2, 10, 10));  // Grid 5x2 untuk 10 obat
        JRadioButton[] radioObat = new JRadioButton[namaObat.length];
        ButtonGroup groupObat = new ButtonGroup();
        
        for (int i = 0; i < namaObat.length; i++) {
            radioObat[i] = new JRadioButton(namaObat[i]);
            groupObat.add(radioObat[i]);
            panelObat.add(radioObat[i]);
        }

        frame.add(panelObat, BorderLayout.CENTER);

        // Panel untuk deskripsi obat (BoxLayout)
        JPanel panelDeskripsi = new JPanel();
        panelDeskripsi.setLayout(new BoxLayout(panelDeskripsi, BoxLayout.Y_AXIS));
        JTextArea areaDeskripsi = new JTextArea(5, 30);
        areaDeskripsi.setEditable(false);
        panelDeskripsi.add(new JLabel("Deskripsi Obat:"));
        panelDeskripsi.add(new JScrollPane(areaDeskripsi));
        frame.add(panelDeskripsi, BorderLayout.SOUTH);

        // Logika pencarian obat berdasarkan gejala
        btnCariObat.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String gejalaDipilih = (String) comboGejala.getSelectedItem();
                StringBuilder obatYangSesuai = new StringBuilder("Obat yang sesuai untuk gejala: " + gejalaDipilih + "\n");
                switch (gejalaDipilih) {
                    case "Demam":
                        obatYangSesuai.append("1. Paracetamol\n");
                        break;
                    case "Infeksi Bakteri":
                        obatYangSesuai.append("1. Amoxicillin\n2. Ciprofloxacin\n");
                        break;
                    case "Nyeri":
                        obatYangSesuai.append("1. Paracetamol\n2. Ibuprofen\n");
                        break;
                    case "Maag":
                        obatYangSesuai.append("1. Antasida\n2. Omeprazole\n");
                        break;
                    case "Alergi":
                        obatYangSesuai.append("1. Cetirizine\n2. Loratadine\n");
                        break;
                    case "Asam Lambung":
                        obatYangSesuai.append("1. Omeprazole\n");
                        break;
                    case "Kolesterol":
                        obatYangSesuai.append("1. Simvastatin\n");
                        break;
                    case "Diabetes":
                        obatYangSesuai.append("1. Metformin\n");
                        break;
                }
                areaDeskripsi.setText(obatYangSesuai.toString());
            }
        });

        // Logika menampilkan deskripsi obat berdasarkan pilihan radio button
        for (int i = 0; i < namaObat.length; i++) {
            final int index = i;
            radioObat[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    areaDeskripsi.setText(deskripsiObat[index]);
                }
            });
        }

        // Konfigurasi frame
        frame.pack();
        frame.setLocationRelativeTo(null);  // Center window
        frame.setVisible(true);
    }
}
