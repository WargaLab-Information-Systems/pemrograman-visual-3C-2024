/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modul_lll;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PembayaranSPP {
    public static void main(String[] args) {
        // Frame utama
        JFrame frame = new JFrame("Pencatatan Pembayaran SPP");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Panel input data menggunakan GridLayout 4x2
        JPanel panelInput = new JPanel(new GridLayout(4, 2, 10, 10));
        
        panelInput.add(new JLabel("Nama Siswa:"));
        JTextField txtNama = new JTextField();
        panelInput.add(txtNama);

        panelInput.add(new JLabel("Jumlah SPP/Bulan (Rp):"));
        JTextField txtJumlahSPP = new JTextField("500000");
        panelInput.add(txtJumlahSPP);

        panelInput.add(new JLabel("Pilih Bulan:"));
        JCheckBox[] bulan = new JCheckBox[12];
        String[] namaBulan = {"Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"};
        JPanel panelBulan = new JPanel(new GridLayout(3, 4));
        for (int i = 0; i < 12; i++) {
            bulan[i] = new JCheckBox(namaBulan[i]);
            panelBulan.add(bulan[i]);
        }
        panelInput.add(panelBulan);
        frame.add(panelInput, BorderLayout.CENTER);

        // Tombol hitung dan cek status menggunakan FlowLayout
        JPanel panelTombol = new JPanel(new FlowLayout());
        JButton btnHitung = new JButton("Hitung Pembayaran");
        JButton btnCekStatus = new JButton("Cek Status Pembayaran");
        panelTombol.add(btnHitung);
        panelTombol.add(btnCekStatus);
        frame.add(panelTombol, BorderLayout.SOUTH);

        // Panel riwayat pembayaran menggunakan BoxLayout
        JPanel panelRiwayat = new JPanel();
        panelRiwayat.setLayout(new BoxLayout(panelRiwayat, BoxLayout.Y_AXIS));
        panelRiwayat.add(new JLabel("Riwayat Pembayaran:"));
        frame.add(new JScrollPane(panelRiwayat), BorderLayout.EAST);

        // Variabel status pembayaran per bulan
        boolean[] statusLunas = new boolean[12];  // Status lunas atau belum lunas untuk tiap bulan
        
        // Event handling untuk tombol Hitung
        btnHitung.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nama = txtNama.getText();
                int jumlahSPP = Integer.parseInt(txtJumlahSPP.getText());
                StringBuilder bulanDipilih = new StringBuilder();
                int totalBayar = 0;
                for (int i = 0; i < 12; i++) {
                    if (bulan[i].isSelected()) {
                        bulanDipilih.append(namaBulan[i]).append(" ");
                        totalBayar += jumlahSPP;
                        statusLunas[i] = true;  // Menandai bulan sebagai lunas
                    }
                }
                // Menampilkan total yang harus dibayar
                panelRiwayat.add(new JLabel("Siswa: " + nama + ", Bulan Dibayar: " + bulanDipilih.toString() + ", Total: Rp" + totalBayar));
                frame.revalidate();
                frame.repaint();
            }
        });

        // Event handling untuk tombol Cek Status
        btnCekStatus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StringBuilder belumLunas = new StringBuilder();
                for (int i = 0; i < 12; i++) {
                    if (!statusLunas[i]) {
                        belumLunas.append(namaBulan[i]).append(" ");
                    }
                }
                if (belumLunas.length() == 0) {
                    JOptionPane.showMessageDialog(frame, "Siswa sudah Lunas.");
                } else {
                    JOptionPane.showMessageDialog(frame, "Siswa Menunggak, Bulan Belum Lunas: " + belumLunas.toString());
                }
            }
        });

        // Konfigurasi frame
        frame.setSize(800, 600);
        frame.setVisible(true);
    }
}
