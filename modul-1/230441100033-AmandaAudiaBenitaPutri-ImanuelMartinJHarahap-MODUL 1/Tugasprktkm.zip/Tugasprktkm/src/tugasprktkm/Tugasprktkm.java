/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tugasprktkm;
import javax.swing.*;
/**
 *
 * @author amand
 */
public class Tugasprktkm {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        tampilanpendaftaranmhs page2 = new tampilanpendaftaranmhs();
        page2.setVisible(true);
        page2.setDefaultCloseOperation(tampilanpendaftaranmhs.EXIT_ON_CLOSE);
    }
    
}
